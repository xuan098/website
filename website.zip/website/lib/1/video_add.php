<?php
require_once 'admin_conn.php';

$conn = connentDb();

if (empty($_POST['name'])||empty($_POST['username'])||empty($_POST['address'])||empty($_POST['play'])){
    die('no');

}

$name = $_POST['name'];
$username = $_POST['username'];
$address = $_POST['address'];
$play = $_POST['play'];

$sql = "INSERT INTO video (vname,vusername,vurl,play) VALUE ('$name','$username','$address','$play') ";

mysqli_query($conn,$sql);

echo "id=".mysqli_insert_id($conn);

echo $sql;

if (mysqli_error($conn)){
    mysqli_error($conn);
}else{
    header('Location:admin_add_video.php');
}