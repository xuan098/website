<?php


//�޸��û���Ϣd

require_once 'admin_conn.php';

$conn = connentDb();


if (empty($_POST['name']) || empty($_POST['username']) || empty($_POST['address'])||empty($_POST['play'])) {
    die('no');
}

$id = intval($_POST['id']);
$name = $_POST['name'];
$username = $_POST['username'];
$address = $_POST['address'];
$play = $_POST['play'];

$sql = "UPDATE video SET vname = '$name',vusername = '$username',vurl = '$address',play = '$play' WHERE vid= $id";

mysqli_query($conn, $sql);

echo $sql;

if (mysqli_error($conn)) {
    die(mysqli_error($conn));
} else {
    header('Location:admin_alter_video.php');
}
