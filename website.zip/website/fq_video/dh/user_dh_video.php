<?php
require_once 'conn.php';
session_start();
$name = $_SESSION['username'];
$conn = connentDb();
$sql = "SELECT * FROM video WHERE fenqu = '动画'";
$result = mysqli_query($conn, $sql);
while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $arr[] = $row['vname'];
    $arr1[] = $row['vusername'];
    $arr2[] = $row['play'];
    $arr3[] = $row['vid'];
}
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="jquery-3.4.1.min.js" type="text/javascript"></script>
    <script src="/website/jquery-accordion-menu.js" type="text/javascript"></script>
    <script src="/website/lib/bootstrap.js" type="text/javascript"></script>
    <link rel="stylesheet" href="/website/lib/bootstrap.css">
    <title>动画</title>
</head>
<body style="padding-top: 61px">
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container" style="width: 80% ;margin: auto">
        <div class="navbar-header">
            <a href="/website/user_index.php" class="navbar-brand"><p style="font-size: 30px">首页</p></a>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="/website/personal/personal.php"><p style="font-size: 25px"><?php echo $name;?></p></a></li>
                <li><a href="/website/fq_video/session_destroy.php"><p style="font-size: 25px">exit</p></a></li>
            </ul>
        </div>
    </div>
</nav>

<div  style="width: 100%; height:150px ; margin: auto;border: 1px solid; background-image: url('002.png');display: flex">
    <div style="width: 80%;height: auto;margin:auto; align-self: center"> <a href="#" style="color: #f4f4f4; text-decoration: none; font-size: 50px;">动画</a></div>
</div>
<div style="width: 85%;height: 1000px;margin: auto;border: 0px solid">
    <div style=";height: auto;margin: auto;border: 0px solid" class="container-fluid"><h2><span class="glyphicon glyphicon-tags" aria-hidden="true" style="font-size: 20px"></span>  热门标签</h2>
        <div class="row" style="padding-top: 10px;padding-bottom: 10px">
            <h3 class="col-md-1"><a class="label label-default">New</a></h3>
            <h3 class="col-md-1"><a class="label label-default">New</a></h3>
            <h3 class="col-md-1"><a class="label label-default">New</a></h3>
            <h3 class="col-md-1"><a class="label label-default">New</a></h3>
            <h3 class="col-md-1"><a class="label label-default">New</a></h3>
        </div>
    </div>
    <div style=";height: auto;margin: auto;border: 0px solid" class="col-md-9">
        <div style="width:100%;height: auto;border-bottom: 1px solid" class="col-md-9">
            <h3><span class="glyphicon glyphicon-file" aria-hidden="true" style="font-size: 20px"></span> 最新投稿</h3>
        </div>
        <div class="row col-md-9" style="width: 100%; padding-top: 20px">
            <div class="col-xs-6 col-md-3">
                <a href="#" class="thumbnail">
                    <img src="005.png" alt="...">
                </a>
                <div style="text-align: center"><h3><?php echo $arr['0']?></h3></div>
            </div>
            <div class="col-xs-6 col-md-3">
                <a href="#" class="thumbnail">
                    <img src="005.png" alt="...">
                </a>
                <div style="text-align: center"><h3><?php echo $arr['0']?></h3></div>
            </div>
            <div class="col-xs-6 col-md-3">
                <a href="#" class="thumbnail">
                    <img src="005.png" alt="...">
                </a>
                <div style="text-align: center"><h3><?php echo $arr['0']?></h3></div>
            </div>
            <div class="col-xs-6 col-md-3">
                <a href="#" class="thumbnail">
                    <img src="005.png" alt="...">
                </a>
                <div style="text-align: center"><h3><?php echo $arr['0']?></h3></div>
            </div>
        </div>
        <div style="width:100%;height: auto;border-bottom: 1px solid" class="col-md-9">
            <h3><span class="glyphicon glyphicon-th" aria-hidden="true" style="font-size: 20px"></span> 全部内容</h3>
        </div>
        <div style="padding-top: 20px;width:100%;height: auto;border-bottom: 0px solid" class="col-md-9">

            <div style="width: 40%; float: left">
                <div class="media">
                    <div class="media-left media-middle">
                        <a href="#">
                            <img class="media-object" src="005.png" alt="...">
                        </a>
                    </div>
                    <div class="media-body">
                        <h4 class="media-heading"><?php echo $arr['0']?></h4>
                        <h5 class="media"><?php echo $arr1['0']?></h5>
                        <h5 class="media">VID: <?php echo $arr3['0']?></h5>
                        <h5 class="media"><span class="glyphicon glyphicon-play-circle" aria-hidden="true" style="font-size: 10px"></span>    <?php echo $arr2['0']?></h5>
                    </div>
                </div>
                <div class="media">
                    <div class="media-left media-middle">
                        <a href="#">
                            <img class="media-object" src="005.png" alt="...">
                        </a>
                    </div>
                    <div class="media-body">
                        <h4 class="media-heading"><?php echo $arr['1']?></h4>
                        <h5 class="media"><?php echo $arr1['1']?></h5>
                        <h5 class="media">VID: <?php echo $arr3['1']?></h5>
                        <h5 class="media"><span class="glyphicon glyphicon-play-circle" aria-hidden="true" style="font-size: 10px"></span>    <?php echo $arr2['1']?></h5>
                    </div>
                </div>
                <div class="media">
                    <div class="media-left media-middle">
                        <a href="#">
                            <img class="media-object" src="005.png" alt="...">
                        </a>
                    </div>
                    <div class="media-body">
                        <h4 class="media-heading"><?php echo $arr['2']?></h4>
                        <h5 class="media"><?php echo $arr1['2']?></h5>
                        <h5 class="media">VID: <?php echo $arr3['2']?></h5>
                        <h5 class="media"><span class="glyphicon glyphicon-play-circle" aria-hidden="true" style="font-size: 10px"></span>    <?php echo $arr2['2']?></h5>
                    </div>
                </div>
                <div class="media">
                    <div class="media-left media-middle">
                        <a href="#">
                            <img class="media-object" src="005.png" alt="...">
                        </a>
                    </div>
                    <div class="media-body">
                        <h4 class="media-heading"><?php echo $arr['0']?></h4>
                        <h5 class="media"><?php echo $arr1['0']?></h5>
                        <h5 class="media">VID: <?php echo $arr3['0']?></h5>
                        <h5 class="media"><span class="glyphicon glyphicon-play-circle" aria-hidden="true" style="font-size: 10px"></span>    <?php echo $arr2['0']?></h5>
                    </div>
                </div>
            </div><!--向后添加-->
            <div style="padding-left: 150px;width: 40%;float: left">
                <div class="media">
                    <div class="media-left media-middle">
                        <a href="#">
                            <img class="media-object" src="005.png" alt="...">
                        </a>
                    </div>
                    <div class="media-body">
                        <h4 class="media-heading"><?php echo $arr['1']?></h4>
                        <h5 class="media"><?php echo $arr1['1']?></h5>
                        <h5 class="media">VID: <?php echo $arr3['1']?></h5>
                        <h5 class="media"><span class="glyphicon glyphicon-play-circle" aria-hidden="true" style="font-size: 10px"></span>    <?php echo $arr2['1']?></h5>
                    </div>
                </div>
                <div class="media">
                    <div class="media-left media-middle">
                        <a href="#">
                            <img class="media-object" src="005.png" alt="...">
                        </a>
                    </div>
                    <div class="media-body">
                        <h4 class="media-heading"><?php echo $arr['2']?></h4>
                        <h5 class="media"><?php echo $arr1['2']?></h5>
                        <h5 class="media">VID: <?php echo $arr3['2']?></h5>
                        <h5 class="media"><span class="glyphicon glyphicon-play-circle" aria-hidden="true" style="font-size: 10px"></span>    <?php echo $arr2['2']?></h5>
                    </div>
                </div>
                <div class="media">
                    <div class="media-left media-middle">
                        <a href="#">
                            <img class="media-object" src="005.png" alt="...">
                        </a>
                    </div>
                    <div class="media-body">
                        <h4 class="media-heading"><?php echo $arr['0']?></h4>
                        <h5 class="media"><?php echo $arr1['0']?></h5>
                        <h5 class="media">VID: <?php echo $arr3['0']?></h5>
                        <h5 class="media"><span class="glyphicon glyphicon-play-circle" aria-hidden="true" style="font-size: 10px"></span>    <?php echo $arr2['0']?></h5>
                    </div>
                </div>
                <div class="media">
                    <div class="media-left media-middle">
                        <a href="#">
                            <img class="media-object" src="005.png" alt="...">
                        </a>
                    </div>
                    <div class="media-body">
                        <h4 class="media-heading"><?php echo $arr['0']?></h4>
                        <h5 class="media"><?php echo $arr1['0']?></h5>
                        <h5 class="media">VID: <?php echo $arr3['0']?></h5>
                        <h5 class="media"><span class="glyphicon glyphicon-play-circle" aria-hidden="true" style="font-size: 10px"></span>    <?php echo $arr2['0']?></h5>
                    </div>
                </div><!--向后添加-->
            </div>
        </div>
    </div>




    <div style="width: 25%;height: auto;border: 1px solid;float: left;" class="col-md-3"><h3><span class="glyphicon glyphicon-th-list" aria-hidden="true" style="font-size: 20px"></span>  排行榜</h3>
        <div style="width: 100%;">11111</div>
    </div>

</body>
</html>