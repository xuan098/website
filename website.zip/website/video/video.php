<?php
require_once 'video_conn.php';
session_start();
$conn = connentDb();
if (!empty($_GET['vid'])){

}else{
    die('no');
}
$id = intval($_GET['vid']);
$sql = "SELECT * FROM video where vid = $id";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_array($result,MYSQLI_BOTH);
$vname = $row['vname'];
$vusername = $row['vusername'];
$play = $row['play'];

$_SESSION['visitor'] = $vusername;
 ?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="../user/jquery-3.4.1.min.js"></script>
    <script src="../user/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../user/bootstrap.min.css">
    <title>video</title>
</head>
<body style="padding-top: 70px">
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container" style="width: 80%;margin: auto">
        <div class="navbar-header">
            <ul class="nav navbar-nav">
                <li><a href="http://localhost/website/index.php" class="navbar-brand"><p style="font-size: 30px">首页</p></a></li>
                <li><a href="#" class="navbar-brand"><p style="font-size: 20px">about</p></a></li>
                <li><a href="#" class="navbar-brand"><p style="font-size: 20px">help</p></a></li>
            </ul>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="/website/user/login.php"><p style="font-size: 25px">
                            登录
                        </p></a></li>
                <li><a href="/website/user/register.php"><p style="font-size: 25px">
                            注册
                        </p></a></li>
            </ul>
        </div>
    </div>
</nav>
<div style="padding-top: 0px ; width: 75%; height: auto; margin: auto;border-bottom: 1px solid" class="row">
    <div class="col-md-9"><h2><?php echo $vname?></h2></div>
    <div class="col-md-3"><h2></h2></div>
</div>
<div style=" padding-top:0px; width: 70%; height: auto; margin: auto; border: 0px solid" class="row">
    <div style=" padding-top: 20px;width: auto; height: auto; border: 0px solid;" class="col-md-9">
        <video style="content" src="ghost01.mp4" controls="controls"></video>
    </div>
    <div style="padding-top: 20px;border: 0px solid" class="col-md-2">其他视频</div>
</div>
<div style="width: 70%; margin: auto;">
    <div style="padding-top: 20px">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <p class="navbar-text"><span class="glyphicon glyphicon-play-circle" aria-hidden="true" style="font-size: 10px"></span>  <?php echo $play?></p>
                <p class="navbar-text"><a href=""><?php echo $vusername?></a></p>
                <p class="navbar-text">上传时间</p>
            </div>
        </nav>
    </div>
</div>
</body>
</html>