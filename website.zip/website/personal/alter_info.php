<?php
//用户修改自己的信息
require_once 'per_conn.php';
session_start();
$id = intval($_SESSION['id']);

$conn = connentDb();

if (empty($_POST['username'])||empty($_POST['password'])||empty($_POST['sex'])||empty($_POST['email'])||empty($_POST['address'])){
    die('no');
}
$name = $_POST['username'];
$password = $_POST['password'];
$sex = $_POST['sex'];
$email = $_POST['email'];
$address = $_POST['address'];
$_SESSION['username'] = $name;

$sql = "UPDATE user SET username = '$name',password = '$password',sex = '$sex',email = '$email',address = '$address' WHERE id= $id";
mysqli_query($conn,$sql);

if (mysqli_error($conn)){
    echo mysqli_error($conn);
}else{
    //echo 'yes';
    header('Location:per_select_info.php');
}