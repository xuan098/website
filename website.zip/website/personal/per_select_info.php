<?php
require_once 'per_conn.php';
session_start();
$username = $_SESSION['username'];

?>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <script src="../user/jquery-3.4.1.min.js"></script>
        <script src="../user/bootstrap.min.js"></script>
        <link rel="stylesheet" href="../user/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../user/style.css">
        <title>
            <?php echo $username;?>的空间
        </title>
    </head>
    <body style=" padding-top: 65px; padding-left: 50px; margin: 0px;">
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container" style="width: 80% ;margin: auto">
            <div class="navbar-header">
                <ul class="nav navbar-nav">
                    <li><a href="http://localhost/website/user_index.php" class="navbar-brand"><p style="font-size: 30px">index</p></a></li>
                    <li><a href="#" class="navbar-brand"><p style="font-size: 20px">about</p></a></li>
                    <li><a href="#" class="navbar-brand"><p style="font-size: 20px">help</p></a></li>
                </ul>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="personal.php"><p style="font-size: 25px">
                                <?php
                                echo $username;
                                ?>
                            </p></a></li>
                    <li><a href="session_destroy.php"><p style="font-size: 25px">
                                exit
                            </p></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div  style=" width: 80%; height: 150px; margin: auto;border: 1px solid; background-image: url('006.png')">
    </div>
    <div style=" padding-top:0px; width: 80%; height: auto; margin: auto; border: 0px solid;" class="row">
        <div class="col-md-9" style="border: 1px"><h2>Welcome To User Center</h2></div>
        <div class="col-md-3" style="border: 1px ;"><h2><?php echo $username;?></h2></div>
    </div>

    <div style="padding-top:0px; width: 80%; height: auto; margin: auto;border-bottom: 1px solid;">
        <!--<div style=" padding-top:0px;float: right;width: 20%;height: 50%;border: 1px solid "></div>-->
        <div style="width:  80%">
            <nav class="navbar" role="navigation" style="border-bottom: 1px solid">
                <div class="container-fluid">
                    <div class="btn-group btn-group-lg">
                        <a type="button" class="btn btn-default navbar-btn label-primary" href="personal.php">
                            用户主页
                        </a>
                    </div>
                    <div class="btn-group btn-group-lg">
                        <a type="button" class="btn btn-default navbar-btn label-primary">
                            用户投稿
                        </a>
                    </div>
                    <div class="btn-group btn-group-lg">
                        <a type="button" class="btn btn-default navbar-btn label-primary" href="per_select_info.php">
                            用户信息
                        </a>
                    </div>
                    <div class="btn-group btn-group-lg">
                        <a type="button" class="btn btn-default navbar-btn label-primary" href="per_alter_info.php">
                            修改信息
                        </a>
                    </div>
                </div>
            </nav>
        </div>
        <div style="width: 80%;">

         <table class="table table-striped table-bordered  table-hover">
             <thead>
             <tr>
                 <th></th>
                 <th>用户信息</th>
             </tr>
             </thead>
             <?php
             $conn = connentDb();
             $sql = "SELECT * FROM user WHERE  username = '$username'";
             $result = mysqli_query($conn,$sql);
             $row = mysqli_fetch_array($result,MYSQLI_BOTH);

             echo "<tbody>
             <tr>
                 <td class='info'>id</td>
                 <td>$row[id]</td>
             </tr>
            <tr>
                <td class='info'>username</td>
                <td>$row[username]</td>
            </tr>
             <tr>
                 <td class='info'>password</td>
                 <td>$row[password]</td>
             </tr>
             <tr>
                 <td class='info'>sex</td>
                 <td>$row[sex]</td>
             </tr>
             <tr>
                 <td class='info'>email</td>
                 <td>$row[email]</td>
             </tr>
             <tr>
                 <td class='info'>address</td>
                 <td>$row[address]</td>
             </tr>
             </tbody>"
              ?>
         </table>
        </div>
    </div>
    </body>
    </html>
<?php
