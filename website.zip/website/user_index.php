<?php
require_once 'conn.php';
session_start();
$username = $_SESSION['username'];
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="style.css" type="text/css" rel="stylesheet"/>
    <script src="jquery-3.4.1.min.js" type="text/javascript"></script>
    <script src="jquery-accordion-menu.js" type="text/javascript"></script>
    <script src="lib/bootstrap.js" type="text/javascript"></script>
    <link rel="stylesheet" href="lib/bootstrap.css">
    <!--<link rel="stylesheet" href="1.css">-->
    <title>website</title>
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="index.php" class="navbar-brand"><p style="font-size: 30px"></p></a>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="personal/personal.php"><p style="font-size: 25px">
                                <?php
                                echo $username;
                                ?>
                            </p></a></li>
                    <li><a href="admin/session_destroy.php"><p style="font-size: 25px">
                                退出
                            </p></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div id="biaoqian1"><a href="index.php" style="color: #f4f4f4; text-decoration: none;padding: " >website</a></div>
<body style="padding-top: 50px">
<div id="quanju">
    <nav class="navbar" style=" width: 80%;    height: auto;    margin: auto;    padding: 20px; border-bottom:1px solid;">
        <!--  <ul class="nav nav-pills">
              <li role="presentation" class="active"><a href="#">Home</a></li>
              <li role="presentation"><a href="#">Profile</a></li>
              <li role="presentation"><a href="#">Messages</a></li>
          </ul>-->
        <div>
            <ul class="nav navbar-nav" style="font-size: 28px; " >
                <li><a href="" style="color: #1a1a1a; text-decoration: none;">首页</a></li>
                <li><a href="/website/fq_video/dh/user_dh_video.php" style="color: #1a1a1a; text-decoration: none;">动画</a></li>
                <li><a href="" style="color: #1a1a1a; text-decoration: none;">番剧</a></li>
                <li><a href="" style="color: #1a1a1a; text-decoration: none;">科技</a></li>
                <li><a href="" style="color: #1a1a1a; text-decoration: none;">鬼畜</a></li>
                <li><a href="" style="color: #1a1a1a; text-decoration: none;">特摄</a></li>
                <li><a href="" style="color: #1a1a1a; text-decoration: none;">电视</a></li>
                <li><a href="" style="color: #1a1a1a; text-decoration: none;">电影</a></li>

            </ul>
        </div>
    </nav>
    <?PHP
    $conn = connentDb();
    $sql = "SELECT * FROM fenqu";
    $result = mysqli_query($conn,$sql);
    while ($row = mysqli_fetch_array($result,MYSQLI_BOTH)){
        $arr[] = $row['fenqu_name'];
    }

    ?>

    <div style="padding-top: 20px ; width: 80%; height: auto; margin: auto;">
        <nav class="navbar navbar-default " role="navigation">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a href="fq_video/dh/user_dh_video.php" class="navbar-brand"><p style="font-size: 25px"><?php  echo $arr[0];?></p></a>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#"><p style="font-size: 10px"></p></a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container-fluid">
            <div class="row" >
                <div class="col-md-9" style="border:1px solid">视频内容
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>1</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>2</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>3</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>4</div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>5</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>6</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>7</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>8</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3" style="border:1px solid">排行榜</div>
            </div>
        </div>
    </div>
    <div style="padding-top: 20px ; width: 80%; height: auto; margin: auto;">
        <nav class="navbar navbar-default " role="navigation">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a href="fq_index.php" class="navbar-brand"><p style="font-size: 25px"><?php echo $arr[1];?></p></a>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#"><p style="font-size: 10px"></p></a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container-fluid">
            <div class="row" >
                <div class="col-md-9" style="border:1px solid">视频内容
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>1</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>2</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>3</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>4</div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>5</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>6</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>7</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>8</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3" style="border:1px solid">排行榜</div>
            </div>
        </div>
    </div>
    <div style="padding-top: 20px ; width: 80%; height: auto; margin: auto;">
        <nav class="navbar navbar-default " role="navigation">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a href="#" class="navbar-brand"><p style="font-size: 25px"><?php echo $arr[2];?></p></a>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#"><p style="font-size: 10px"></p></a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container-fluid">
            <div class="row" >
                <div class="col-md-9" style="border:1px solid">视频内容
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>1</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>2</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>3</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>4</div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>5</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>6</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>7</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>8</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3" style="border:1px solid">排行榜</div>
            </div>
        </div>
    </div>
    <div style="padding-top: 20px ; width: 80%; height: auto; margin: auto;">
        <nav class="navbar navbar-default " role="navigation">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a href="#" class="navbar-brand"><p style="font-size: 25px"><?php echo $arr[3];?></p></a>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#"><p style="font-size: 10px"></p></a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container-fluid">
            <div class="row" >
                <div class="col-md-9" style="border:1px solid">视频内容
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>1</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>2</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>3</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>4</div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>5</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>6</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>7</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>8</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3" style="border:1px solid">排行榜</div>
            </div>
        </div>
    </div>
    <div style="padding-top: 20px ; width: 80%; height: auto; margin: auto;">
        <nav class="navbar navbar-default " role="navigation">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a href="#" class="navbar-brand"><p style="font-size: 25px"><?php echo $arr[4];?></p></a>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#"><p style="font-size: 10px"></p></a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container-fluid">
            <div class="row" >
                <div class="col-md-9" style="border:1px solid">视频内容
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>1</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>2</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>3</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>4</div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>5</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>6</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>7</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>8</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3" style="border:1px solid">排行榜</div>
            </div>
        </div>
    </div>
    <div style="padding-top: 20px ; width: 80%; height: auto; margin: auto;">
        <nav class="navbar navbar-default " role="navigation">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a href="#" class="navbar-brand"><p style="font-size: 25px"><?php echo $arr[5];?></p></a>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#"><p style="font-size: 10px"></p></a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container-fluid">
            <div class="row" >
                <div class="col-md-9" style="border:1px solid">视频内容
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>1</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>2</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>3</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>4</div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>5</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>6</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>7</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>8</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3" style="border:1px solid">排行榜</div>
            </div>
        </div>
    </div>

    <div style="padding-top: 20px ; width: 80%; height: auto; margin: auto;">
        <nav class="navbar navbar-default " role="navigation">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a href="#" class="navbar-brand"><p style="font-size: 25px"><?php echo $arr[6];?></p></a>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#"><p style="font-size: 10px"></p></a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container-fluid">
            <div class="row" >
                <div class="col-md-9" style="border:1px solid">视频内容
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>1</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>2</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>3</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>4</div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>5</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>6</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>7</div>
                        </div>
                        <div class="col-xs-6 col-md-3">
                            <a href="#" class="thumbnail">
                                <img src="..." alt="...">
                            </a>
                            <div>8</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3" style="border:1px solid">排行榜</div>
            </div>
        </div>
    </div>

    <div style="padding-top: 20px ; width: 80%; height: auto; margin: auto;">
        <nav class="navbar navbar-default " role="navigation">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a href="#" class="navbar-brand"><p style="font-size: 25px"></p></a>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#"><p style="font-size: 10px"></p></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
    <div id="dibuneirong" align="center" style=""><br>
        炫098<br>
        qq：931340447<br>
        邮箱：931340447@qq.com<br>
        AV419<br>
        如有问题请联系我！！！！！！！<br>
        <script>
            document.write(Date());
        </script>
    </div>
</div>
</body>
</html>