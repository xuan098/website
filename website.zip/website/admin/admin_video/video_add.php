<?php
require_once 'admin_conn.php';

$conn = connentDb();

if (empty($_POST['name'])||empty($_POST['username'])||empty($_POST['address'])||empty($_POST['play'])){
    die('no');

}

$name = $_POST['name'];
$username = $_POST['username'];
$address = $_POST['address'];
$play = $_POST['play'];
$fenqu = $_POST['fenqu'];

$sql = "INSERT INTO video (vname,vusername,vurl,play,fenqu) VALUE ('$name','$username','$address','$play','$fenqu') ";
$sql1 = "INSERT INTO user_video (vname,username) VALUE ('$name','$username') ";
$sql2 = "INSERT INTO fenqu_video (vname,fenqu_name) VALUE ('$name','$fenqu') ";

mysqli_query($conn,$sql);
mysqli_query($conn,$sql1);
mysqli_query($conn,$sql2);
echo "id=".mysqli_insert_id($conn);

echo $sql;

if (mysqli_error($conn)){
    mysqli_error($conn);
}else{
    header("Content-Type: text/html; charset=utf-8");
    header('Location:admin_add_video.php');
}