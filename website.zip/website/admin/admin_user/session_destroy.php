<?php
//退出用户 销毁session
session_start();
session_destroy();
header('Location:http://localhost/website/index.php');